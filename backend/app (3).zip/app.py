from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from jose import jwt, JWTError
from datetime import datetime, timedelta

from database import SessionLocal, engine
import models
models.Base.metadata.create_all(bind=engine)

# ==================================================
# APP
# ==================================================

app = FastAPI(
    title="Vendor Reliability Platform",
    version="1.0.0"
)


# ==================================================
# CORS
# ==================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ==================================================
# JWT SETTINGS
# ==================================================

SECRET_KEY = "vrip-secret-key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60


# ==================================================
# HTTP BEARER
# ==================================================

security = HTTPBearer(auto_error=False)


# ==================================================
# REQUEST MODELS
# ==================================================

class VendorCreate(BaseModel):
    name: str
    email: str
    phone: str
    category_id: int | None = None


class VendorUpdate(BaseModel):
    name: str
    email: str
    phone: str
    category_id: int | None = None


class VendorCategoryCreate(BaseModel):
    name: str


class UserCreate(BaseModel):
    name: str
    email: str
    password: str


class UserLogin(BaseModel):
    email: str
    password: str


class PurchaseOrderCreate(BaseModel):
    vendor_name: str
    item_service: str
    total_cost: str
    status: str
class ProcurementRequestCreate(BaseModel):
    requester: str
    department: str
    item: str
    quantity: int
    estimated_cost: float
    status: str
class ContractCreate(BaseModel):
    vendor_id: int
    start_date: str
    expiry_date: str
    renewal_notice_period: int
    terms: str
    compliance_flags: str
class ContractDocumentCreate(BaseModel):
    contract_id: int
    document_name: str
    document_path: str


class InvoiceCreate(BaseModel):
    po_id: int
    invoice_number: str
    amount: float
    status: str

# ==================================================
# JWT TOKEN VERIFICATION
# ==================================================

def verify_token(
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    if credentials is None:
        raise HTTPException(
            status_code=401,
            detail="Authorization token missing"
        )

    token = credentials.credentials

    try:
        payload = jwt.decode(
            token,
            SECRET_KEY,
            algorithms=[ALGORITHM]
        )

        email = payload.get("sub")

        if email is None:
            raise HTTPException(
                status_code=401,
                detail="Invalid token"
            )

        return email

    except JWTError:
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired token"
        )


# ==================================================
# HOME
# ==================================================

@app.get("/")
def home():
    return {
        "message": "Vendor Reliability Platform Backend"
    }


# ==================================================
# REGISTER
# ==================================================

@app.post("/register")
def register_user(user: UserCreate):

    db = SessionLocal()

    try:

        existing_user = (
            db.query(models.User)
            .filter(models.User.email == user.email)
            .first()
        )

        if existing_user:
            return {
                "message": "User email already exists"
            }

        new_user = models.User(
            name=user.name,
            email=user.email,
            password=user.password
        )

        db.add(new_user)
        db.commit()
        db.refresh(new_user)

        return {
            "message": "Registration Successful"
        }

    finally:
        db.close()


# ==================================================
# LOGIN
# ==================================================

@app.post("/login")
def login(user: UserLogin):

    db = SessionLocal()

    try:

        existing_user = (
            db.query(models.User)
            .filter(
                models.User.email == user.email,
                models.User.password == user.password
            )
            .first()
        )

        if not existing_user:
            raise HTTPException(
                status_code=401,
                detail="Invalid Email or Password"
            )

        expire = datetime.utcnow() + timedelta(
            minutes=ACCESS_TOKEN_EXPIRE_MINUTES
        )

        token_data = {
            "sub": existing_user.email,
            "exp": expire
        }

        access_token = jwt.encode(
            token_data,
            SECRET_KEY,
            algorithm=ALGORITHM
        )

        return {
            "message": "Login Successful",
            "access_token": access_token,
            "token_type": "bearer"
        }

    finally:
        db.close()


# ==================================================
# VENDOR CATEGORY
# ==================================================

@app.post("/vendor-categories")
def create_vendor_category(
    category: VendorCategoryCreate,
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        existing_category = (
            db.query(models.VendorCategory)
            .filter(
                models.VendorCategory.name == category.name
            )
            .first()
        )

        if existing_category:
            raise HTTPException(
                status_code=400,
                detail="Category already exists"
            )

        new_category = models.VendorCategory(
            name=category.name
        )

        db.add(new_category)
        db.commit()
        db.refresh(new_category)

        return {
            "message": "Vendor category created successfully",
            "category": {
                "id": new_category.id,
                "name": new_category.name
            }
        }

    finally:
        db.close()


# ==================================================
# GET VENDOR CATEGORIES
# ==================================================

@app.get("/vendor-categories")
def get_vendor_categories(
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        categories = (
            db.query(models.VendorCategory)
            .order_by(models.VendorCategory.id)
            .all()
        )

        return [
            {
                "id": category.id,
                "name": category.name
            }
            for category in categories
        ]

    finally:
        db.close()


# ==================================================
# GET VENDORS
# ==================================================

@app.get("/vendors")
def get_vendors(
    search: str | None = None,
    category_id: int | None = None,
    approval_status: str | None = None,
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        query = db.query(models.Vendor)

        # Search by vendor name or email
        if search:
            query = query.filter(
                (models.Vendor.name.ilike(f"%{search}%")) |
                (models.Vendor.email.ilike(f"%{search}%"))
            )

        # Filter by category
        if category_id is not None:
            query = query.filter(
                models.Vendor.category_id == category_id
            )

        # Filter by approval status
        if approval_status:
            query = query.filter(
                models.Vendor.approval_status == approval_status
            )

        vendors = query.order_by(models.Vendor.id).all()

        result = []

        for vendor in vendors:

            category_name = None

            if vendor.category:
                category_name = vendor.category.name

            result.append({
                "id": vendor.id,
                "name": vendor.name,
                "email": vendor.email,
                "phone": vendor.phone,
                "category_id": vendor.category_id,
                "category_name": category_name,
                "approval_status": vendor.approval_status
            })

        return result

    finally:
        db.close()


# ==================================================
# GET SINGLE VENDOR
# ==================================================

@app.get("/vendors/{vendor_id}")
def get_vendor(
    vendor_id: int,
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        vendor = (
            db.query(models.Vendor)
            .filter(models.Vendor.id == vendor_id)
            .first()
        )

        if not vendor:
            raise HTTPException(
                status_code=404,
                detail="Vendor not found"
            )

        category_name = None

        if vendor.category:
            category_name = vendor.category.name

        contacts = [
            {
                "id": contact.id,
                "contact_name": contact.contact_name,
                "email": contact.email,
                "phone": contact.phone
            }
            for contact in vendor.contacts
        ]

        return {
            "id": vendor.id,
            "name": vendor.name,
            "email": vendor.email,
            "phone": vendor.phone,
            "category_id": vendor.category_id,
            "category_name": category_name,
            "approval_status": vendor.approval_status,
            "contacts": contacts
        }

    finally:
        db.close()


# ==================================================
# ADD VENDOR
# ==================================================

@app.post("/vendors")
def add_vendor(
    vendor: VendorCreate,
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        existing_vendor = (
            db.query(models.Vendor)
            .filter(models.Vendor.email == vendor.email)
            .first()
        )

        if existing_vendor:
            raise HTTPException(
                status_code=400,
                detail="Vendor email already exists"
            )

        # Check category
        if vendor.category_id is not None:

            category = (
                db.query(models.VendorCategory)
                .filter(
                    models.VendorCategory.id == vendor.category_id
                )
                .first()
            )

            if not category:
                raise HTTPException(
                    status_code=404,
                    detail="Vendor category not found"
                )

        new_vendor = models.Vendor(
            name=vendor.name,
            email=vendor.email,
            phone=vendor.phone,
            category_id=vendor.category_id,
            approval_status="Pending"
        )

        db.add(new_vendor)
        db.commit()
        db.refresh(new_vendor)

        category_name = None

        if new_vendor.category:
            category_name = new_vendor.category.name

        return {
            "message": "Vendor added successfully",
            "vendor": {
                "id": new_vendor.id,
                "name": new_vendor.name,
                "email": new_vendor.email,
                "phone": new_vendor.phone,
                "category_id": new_vendor.category_id,
                "category_name": category_name,
                "approval_status": new_vendor.approval_status
            }
        }

    finally:
        db.close()


# ==================================================
# UPDATE VENDOR
# ==================================================

@app.put("/vendors/{vendor_id}")
def update_vendor(
    vendor_id: int,
    vendor_data: VendorUpdate,
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        vendor = (
            db.query(models.Vendor)
            .filter(models.Vendor.id == vendor_id)
            .first()
        )

        if not vendor:
            raise HTTPException(
                status_code=404,
                detail="Vendor not found"
            )

        # Check duplicate email
        existing_vendor = (
            db.query(models.Vendor)
            .filter(
                models.Vendor.email == vendor_data.email,
                models.Vendor.id != vendor_id
            )
            .first()
        )

        if existing_vendor:
            raise HTTPException(
                status_code=400,
                detail="Another vendor already uses this email"
            )

        # Check category
        if vendor_data.category_id is not None:

            category = (
                db.query(models.VendorCategory)
                .filter(
                    models.VendorCategory.id == vendor_data.category_id
                )
                .first()
            )

            if not category:
                raise HTTPException(
                    status_code=404,
                    detail="Vendor category not found"
                )

        vendor.name = vendor_data.name
        vendor.email = vendor_data.email
        vendor.phone = vendor_data.phone
        vendor.category_id = vendor_data.category_id

        db.commit()
        db.refresh(vendor)

        return {
            "message": "Vendor updated successfully",
            "vendor": {
                "id": vendor.id,
                "name": vendor.name,
                "email": vendor.email,
                "phone": vendor.phone,
                "category_id": vendor.category_id,
                "approval_status": vendor.approval_status
            }
        }

    finally:
        db.close()


# ==================================================
# DELETE VENDOR
# ==================================================

@app.delete("/vendors/{vendor_id}")
def delete_vendor(
    vendor_id: int,
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        vendor = (
            db.query(models.Vendor)
            .filter(models.Vendor.id == vendor_id)
            .first()
        )

        if not vendor:
            raise HTTPException(
                status_code=404,
                detail="Vendor not found"
            )

        db.delete(vendor)
        db.commit()

        return {
            "message": "Vendor deleted successfully"
        }
    finally:
        db.close()
# ==================================================
# ==================================================
# REVIEW VENDOR
# ==================================================

@app.put("/vendors/{vendor_id}/review")
def review_vendor(
    vendor_id: int,
    current_user: str = Depends(verify_token)
):
    db = SessionLocal()

    try:
        vendor = (
            db.query(models.Vendor)
            .filter(models.Vendor.id == vendor_id)
            .first()
        )

        if not vendor:
            raise HTTPException(
                status_code=404,
                detail="Vendor not found"
            )

        vendor.approval_status = "Under Review"

        db.commit()
        db.refresh(vendor)

        return {
            "message": "Vendor moved to Under Review",
            "vendor_id": vendor.id,
            "approval_status": vendor.approval_status
        }

    finally:
        db.close()


# ==================================================
# APPROVE VENDOR
# ==================================================

@app.put("/vendors/{vendor_id}/approve")
def approve_vendor(
    vendor_id: int,
    current_user: str = Depends(verify_token)
):
    db = SessionLocal()

    try:
        vendor = (
            db.query(models.Vendor)
            .filter(models.Vendor.id == vendor_id)
            .first()
        )

        if not vendor:
            raise HTTPException(
                status_code=404,
                detail="Vendor not found"
            )

        vendor.approval_status = "Approved"

        db.commit()
        db.refresh(vendor)

        return {
            "message": "Vendor approved successfully",
            "vendor_id": vendor.id,
            "approval_status": vendor.approval_status
        }

    finally:
        db.close()


# ==================================================
# REJECT VENDOR
# ==================================================

@app.put("/vendors/{vendor_id}/reject")
def reject_vendor(
    vendor_id: int,
    current_user: str = Depends(verify_token)
):
    db = SessionLocal()

    try:
        vendor = (
            db.query(models.Vendor)
            .filter(models.Vendor.id == vendor_id)
            .first()
        )

        if not vendor:
            raise HTTPException(
                status_code=404,
                detail="Vendor not found"
            )

        vendor.approval_status = "Rejected"

        db.commit()
        db.refresh(vendor)

        return {
            "message": "Vendor rejected successfully",
            "vendor_id": vendor.id,
            "approval_status": vendor.approval_status
        }

    finally:
        db.close()

# =========================
# PURCHASE ORDERS
# =========================
@app.post("/purchase-orders")
def create_purchase_order(po: PurchaseOrderCreate):
    db = SessionLocal()

    try:
        new_po = models.PurchaseOrder(
            vendor_name=po.vendor_name,
            item_service=po.item_service,
            total_cost=po.total_cost,
            status=po.status
        )

        db.add(new_po)
        db.commit()
        db.refresh(new_po)

        return {
            "message": "Purchase Order Created Successfully",
            "data": new_po
        }

    finally:
        db.close()


@app.get("/purchase-orders")
def get_purchase_orders():
    db = SessionLocal()

    try:
        return db.query(models.PurchaseOrder).all()
    finally:
        db.close()

# =========================
# PURCHASE ORDER DELIVERY TRACKING
# =========================

@app.put("/purchase-orders/{po_id}/shipped")
def mark_po_shipped(po_id: int):
    db = SessionLocal()

    try:
        po = db.query(models.PurchaseOrder).filter(
            models.PurchaseOrder.id == po_id
        ).first()

        if not po:
            raise HTTPException(status_code=404, detail="Purchase Order not found")

        po.status = "Shipped"

        db.commit()
        db.refresh(po)

        return {
            "message": "Purchase Order marked as Shipped",
            "data": po
        }

    finally:
        db.close()


@app.put("/purchase-orders/{po_id}/partial-delivery")
def mark_po_partial_delivery(po_id: int):
    db = SessionLocal()

    try:
        po = db.query(models.PurchaseOrder).filter(
            models.PurchaseOrder.id == po_id
        ).first()

        if not po:
            raise HTTPException(status_code=404, detail="Purchase Order not found")

        po.status = "Partial Delivery"

        db.commit()
        db.refresh(po)

        return {
            "message": "Purchase Order marked as Partial Delivery",
            "data": po
        }

    finally:
        db.close()


@app.put("/purchase-orders/{po_id}/delivered")
def mark_po_delivered(po_id: int):
    db = SessionLocal()

    try:
        po = db.query(models.PurchaseOrder).filter(
            models.PurchaseOrder.id == po_id
        ).first()

        if not po:
            raise HTTPException(status_code=404, detail="Purchase Order not found")

        po.status = "Delivered"

        db.commit()
        db.refresh(po)

        return {
            "message": "Purchase Order marked as Delivered",
            "data": po
        }

    finally:
        db.close()


# =========================
# PROCUREMENT REQUESTS
# =========================

@app.post("/procurement-requests")
def create_procurement_request(request: ProcurementRequestCreate):
    db = SessionLocal()

    try:
        new_request = models.ProcurementRequest(
            requester=request.requester,
            department=request.department,
            item=request.item,
            quantity=request.quantity,
            estimated_cost=request.estimated_cost,
            status=request.status
        )

        db.add(new_request)
        db.commit()
        db.refresh(new_request)

        return {
            "message": "Procurement Request Created Successfully",
            "data": new_request
        }

    finally:
        db.close()

@app.get("/procurement-requests")
def get_procurement_requests():
    db = SessionLocal()

    try:
        return db.query(models.ProcurementRequest).all()
    finally:
        db.close()
# =========================
# PROCUREMENT APPROVAL
# =========================

@app.put("/procurement-requests/{request_id}/approve")
def approve_procurement_request(request_id: int):
    db = SessionLocal()

    try:
        pr = db.query(models.ProcurementRequest).filter(
            models.ProcurementRequest.id == request_id
        ).first()

        if not pr:
            raise HTTPException(status_code=404, detail="Request not found")

        pr.status = "Approved"

        db.commit()
        db.refresh(pr)

        return {
            "message": "Procurement Request Approved",
            "data": pr
        }

    finally:
        db.close()


@app.put("/procurement-requests/{request_id}/ordered")
def ordered_procurement_request(request_id: int):
    db = SessionLocal()

    try:
        pr = db.query(models.ProcurementRequest).filter(
            models.ProcurementRequest.id == request_id
        ).first()

        if not pr:
            raise HTTPException(status_code=404, detail="Request not found")

        pr.status = "Ordered"

        db.commit()
        db.refresh(pr)

        return {
            "message": "Status changed to Ordered",
            "data": pr
        }

    finally:
        db.close()


@app.put("/procurement-requests/{request_id}/delivered")
def delivered_procurement_request(request_id: int):
    db = SessionLocal()

    try:
        pr = db.query(models.ProcurementRequest).filter(
            models.ProcurementRequest.id == request_id
        ).first()

        if not pr:
            raise HTTPException(status_code=404, detail="Request not found")

        pr.status = "Delivered"

        db.commit()
        db.refresh(pr)

        return {
            "message": "Status changed to Delivered",
            "data": pr
        }

    finally:
        db.close()


@app.put("/procurement-requests/{request_id}/completed")
def completed_procurement_request(request_id: int):
    db = SessionLocal()

    try:
        pr = db.query(models.ProcurementRequest).filter(
            models.ProcurementRequest.id == request_id
        ).first()

        if not pr:
            raise HTTPException(status_code=404, detail="Request not found")

        pr.status = "Completed"

        db.commit()
        db.refresh(pr)

        return {
            "message": "Status changed to Completed",
            "data": pr
        }

    finally:
        db.close()     