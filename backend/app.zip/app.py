from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from jose import jwt, JWTError
from datetime import datetime, timedelta

from database import SessionLocal
import models


# ==================================================
# APP
# ==================================================

app = FastAPI(
    title="Vendor Reliability Platform",
    version="1.0.0"
)


# ==================================================
# CORS
# ==================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ==================================================
# JWT SETTINGS
# ==================================================

SECRET_KEY = "vrip-secret-key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60


# ==================================================
# HTTP BEARER
# ==================================================

security = HTTPBearer()


# ==================================================
# REQUEST MODELS
# ==================================================

class VendorCreate(BaseModel):
    name: str
    email: str
    phone: str
    category_id: int | None = None


class VendorUpdate(BaseModel):
    name: str
    email: str
    phone: str
    category_id: int | None = None


class VendorCategoryCreate(BaseModel):
    name: str


class UserCreate(BaseModel):
    name: str
    email: str
    password: str


class UserLogin(BaseModel):
    email: str
    password: str


class PurchaseOrderCreate(BaseModel):
    vendor_name: str
    item_service: str
    total_cost: float
    status: str = "Pending"


# ==================================================
# JWT TOKEN VERIFICATION
# ==================================================

def verify_token(
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    token = credentials.credentials

    try:

        payload = jwt.decode(
            token,
            SECRET_KEY,
            algorithms=[ALGORITHM]
        )

        email = payload.get("sub")

        if not email:
            raise HTTPException(
                status_code=401,
                detail="Invalid token"
            )

        return email

    except JWTError:
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired token"
        )


# ==================================================
# HOME
# ==================================================

@app.get("/")
def home():
    return {
        "message": "Vendor Reliability Platform Backend"
    }


# ==================================================
# REGISTER
# ==================================================

@app.post("/register")
def register_user(user: UserCreate):

    db = SessionLocal()

    try:

        existing_user = (
            db.query(models.User)
            .filter(models.User.email == user.email)
            .first()
        )

        if existing_user:
            return {
                "message": "User email already exists"
            }

        new_user = models.User(
            name=user.name,
            email=user.email,
            password=user.password
        )

        db.add(new_user)
        db.commit()
        db.refresh(new_user)

        return {
            "message": "Registration Successful"
        }

    finally:
        db.close()


# ==================================================
# LOGIN
# ==================================================

@app.post("/login")
def login(user: UserLogin):

    db = SessionLocal()

    try:

        existing_user = (
            db.query(models.User)
            .filter(
                models.User.email == user.email,
                models.User.password == user.password
            )
            .first()
        )

        if not existing_user:
            raise HTTPException(
                status_code=401,
                detail="Invalid Email or Password"
            )

        expire = datetime.utcnow() + timedelta(
            minutes=ACCESS_TOKEN_EXPIRE_MINUTES
        )

        token_data = {
            "sub": existing_user.email,
            "exp": expire
        }

        access_token = jwt.encode(
            token_data,
            SECRET_KEY,
            algorithm=ALGORITHM
        )

        return {
            "message": "Login Successful",
            "access_token": access_token,
            "token_type": "bearer"
        }

    finally:
        db.close()


# ==================================================
# VENDOR CATEGORY
# ==================================================

@app.post("/vendor-categories")
def create_vendor_category(
    category: VendorCategoryCreate,
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        existing_category = (
            db.query(models.VendorCategory)
            .filter(
                models.VendorCategory.name == category.name
            )
            .first()
        )

        if existing_category:
            raise HTTPException(
                status_code=400,
                detail="Category already exists"
            )

        new_category = models.VendorCategory(
            name=category.name
        )

        db.add(new_category)
        db.commit()
        db.refresh(new_category)

        return {
            "message": "Vendor category created successfully",
            "category": {
                "id": new_category.id,
                "name": new_category.name
            }
        }

    finally:
        db.close()


# ==================================================
# GET VENDOR CATEGORIES
# ==================================================

@app.get("/vendor-categories")
def get_vendor_categories(
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        categories = (
            db.query(models.VendorCategory)
            .order_by(models.VendorCategory.id)
            .all()
        )

        return [
            {
                "id": category.id,
                "name": category.name
            }
            for category in categories
        ]

    finally:
        db.close()


# ==================================================
# GET VENDORS
# ==================================================

@app.get("/vendors")
def get_vendors(
    search: str | None = None,
    category_id: int | None = None,
    approval_status: str | None = None,
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        query = db.query(models.Vendor)

        # Search by vendor name or email
        if search:
            query = query.filter(
                (models.Vendor.name.ilike(f"%{search}%")) |
                (models.Vendor.email.ilike(f"%{search}%"))
            )

        # Filter by category
        if category_id is not None:
            query = query.filter(
                models.Vendor.category_id == category_id
            )

        # Filter by approval status
        if approval_status:
            query = query.filter(
                models.Vendor.approval_status == approval_status
            )

        vendors = query.order_by(models.Vendor.id).all()

        result = []

        for vendor in vendors:

            category_name = None

            if vendor.category:
                category_name = vendor.category.name

            result.append({
                "id": vendor.id,
                "name": vendor.name,
                "email": vendor.email,
                "phone": vendor.phone,
                "category_id": vendor.category_id,
                "category_name": category_name,
                "approval_status": vendor.approval_status
            })

        return result

    finally:
        db.close()


# ==================================================
# GET SINGLE VENDOR
# ==================================================

@app.get("/vendors/{vendor_id}")
def get_vendor(
    vendor_id: int,
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        vendor = (
            db.query(models.Vendor)
            .filter(models.Vendor.id == vendor_id)
            .first()
        )

        if not vendor:
            raise HTTPException(
                status_code=404,
                detail="Vendor not found"
            )

        category_name = None

        if vendor.category:
            category_name = vendor.category.name

        contacts = [
            {
                "id": contact.id,
                "contact_name": contact.contact_name,
                "email": contact.email,
                "phone": contact.phone
            }
            for contact in vendor.contacts
        ]

        return {
            "id": vendor.id,
            "name": vendor.name,
            "email": vendor.email,
            "phone": vendor.phone,
            "category_id": vendor.category_id,
            "category_name": category_name,
            "approval_status": vendor.approval_status,
            "contacts": contacts
        }

    finally:
        db.close()


# ==================================================
# ADD VENDOR
# ==================================================

@app.post("/vendors")
def add_vendor(
    vendor: VendorCreate,
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        existing_vendor = (
            db.query(models.Vendor)
            .filter(models.Vendor.email == vendor.email)
            .first()
        )

        if existing_vendor:
            raise HTTPException(
                status_code=400,
                detail="Vendor email already exists"
            )

        # Check category
        if vendor.category_id is not None:

            category = (
                db.query(models.VendorCategory)
                .filter(
                    models.VendorCategory.id == vendor.category_id
                )
                .first()
            )

            if not category:
                raise HTTPException(
                    status_code=404,
                    detail="Vendor category not found"
                )

        new_vendor = models.Vendor(
            name=vendor.name,
            email=vendor.email,
            phone=vendor.phone,
            category_id=vendor.category_id,
            approval_status="Pending"
        )

        db.add(new_vendor)
        db.commit()
        db.refresh(new_vendor)

        category_name = None

        if new_vendor.category:
            category_name = new_vendor.category.name

        return {
            "message": "Vendor added successfully",
            "vendor": {
                "id": new_vendor.id,
                "name": new_vendor.name,
                "email": new_vendor.email,
                "phone": new_vendor.phone,
                "category_id": new_vendor.category_id,
                "category_name": category_name,
                "approval_status": new_vendor.approval_status
            }
        }

    finally:
        db.close()


# ==================================================
# UPDATE VENDOR
# ==================================================

@app.put("/vendors/{vendor_id}")
def update_vendor(
    vendor_id: int,
    vendor_data: VendorUpdate,
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        vendor = (
            db.query(models.Vendor)
            .filter(models.Vendor.id == vendor_id)
            .first()
        )

        if not vendor:
            raise HTTPException(
                status_code=404,
                detail="Vendor not found"
            )

        # Check duplicate email
        existing_vendor = (
            db.query(models.Vendor)
            .filter(
                models.Vendor.email == vendor_data.email,
                models.Vendor.id != vendor_id
            )
            .first()
        )

        if existing_vendor:
            raise HTTPException(
                status_code=400,
                detail="Another vendor already uses this email"
            )

        # Check category
        if vendor_data.category_id is not None:

            category = (
                db.query(models.VendorCategory)
                .filter(
                    models.VendorCategory.id == vendor_data.category_id
                )
                .first()
            )

            if not category:
                raise HTTPException(
                    status_code=404,
                    detail="Vendor category not found"
                )

        vendor.name = vendor_data.name
        vendor.email = vendor_data.email
        vendor.phone = vendor_data.phone
        vendor.category_id = vendor_data.category_id

        db.commit()
        db.refresh(vendor)

        return {
            "message": "Vendor updated successfully",
            "vendor": {
                "id": vendor.id,
                "name": vendor.name,
                "email": vendor.email,
                "phone": vendor.phone,
                "category_id": vendor.category_id,
                "approval_status": vendor.approval_status
            }
        }

    finally:
        db.close()


# ==================================================
# DELETE VENDOR
# ==================================================

@app.delete("/vendors/{vendor_id}")
def delete_vendor(
    vendor_id: int,
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        vendor = (
            db.query(models.Vendor)
            .filter(models.Vendor.id == vendor_id)
            .first()
        )

        if not vendor:
            raise HTTPException(
                status_code=404,
                detail="Vendor not found"
            )

        db.delete(vendor)
        db.commit()

        return {
            "message": "Vendor deleted successfully"
        }

    finally:
        db.close()


# ==================================================
# APPROVE VENDOR
# ==================================================

@app.put("/vendors/{vendor_id}/approve")
def approve_vendor(
    vendor_id: int,
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        vendor = (
            db.query(models.Vendor)
            .filter(models.Vendor.id == vendor_id)
            .first()
        )

        if not vendor:
            raise HTTPException(
                status_code=404,
                detail="Vendor not found"
            )

        vendor.approval_status = "Approved"

        db.commit()
        db.refresh(vendor)

        return {
            "message": "Vendor approved successfully",
            "vendor_id": vendor.id,
            "approval_status": vendor.approval_status
        }

    finally:
        db.close()


# ==================================================
# REJECT VENDOR
# ==================================================

@app.put("/vendors/{vendor_id}/reject")
def reject_vendor(
    vendor_id: int,
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        vendor = (
            db.query(models.Vendor)
            .filter(models.Vendor.id == vendor_id)
            .first()
        )

        if not vendor:
            raise HTTPException(
                status_code=404,
                detail="Vendor not found"
            )

        vendor.approval_status = "Rejected"

        db.commit()
        db.refresh(vendor)

        return {
            "message": "Vendor rejected successfully",
            "vendor_id": vendor.id,
            "approval_status": vendor.approval_status
        }

    finally:
        db.close()


# ==================================================
# GET PURCHASE ORDERS
# ==================================================

@app.get("/purchase-orders")
def get_purchase_orders(
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        orders = db.query(models.PurchaseOrder).all()

        return [
            {
                "id": order.id,
                "vendor_name": order.vendor_name,
                "item_service": order.item_service,
                "total_cost": order.total_cost,
                "status": order.status
            }
            for order in orders
        ]

    finally:
        db.close()


# ==================================================
# CREATE PURCHASE ORDER
# ==================================================

@app.post("/purchase-orders")
def create_purchase_order(
    order: PurchaseOrderCreate,
    current_user: str = Depends(verify_token)
):

    db = SessionLocal()

    try:

        new_order = models.PurchaseOrder(
            vendor_name=order.vendor_name,
            item_service=order.item_service,
            total_cost=order.total_cost,
            status=order.status
        )

        db.add(new_order)
        db.commit()
        db.refresh(new_order)

        return {
            "message": "Purchase Order Created Successfully",
            "order": {
                "id": new_order.id,
                "vendor_name": new_order.vendor_name,
                "item_service": new_order.item_service,
                "total_cost": new_order.total_cost,
                "status": new_order.status
            }
        }

    finally:
        db.close()